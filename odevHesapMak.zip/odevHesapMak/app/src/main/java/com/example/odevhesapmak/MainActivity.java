package com.example.odevhesapmak;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

long s1,s2,sM;
int islemNo=-1;
TextView txtGirdi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtGirdi=(TextView)findViewById(R.id.txtGirdi);



    }
    public void clickMethod(View view) throws InterruptedException {
        Button bTmp=(Button) view;
        Toast.makeText(getApplicationContext(),"Basıldı=> "+bTmp.getText(),Toast.LENGTH_LONG).show();
        if(bTmp.getText().toString().equals("0")){txtGirdi.setText(txtGirdi.getText()+bTmp.getText().toString());}
        if(bTmp.getText().toString().equals("1")){txtGirdi.setText(txtGirdi.getText()+bTmp.getText().toString());}
        if(bTmp.getText().toString().equals("2")){txtGirdi.setText(txtGirdi.getText()+bTmp.getText().toString());}
        if(bTmp.getText().toString().equals("3")){txtGirdi.setText(txtGirdi.getText()+bTmp.getText().toString());}
        if(bTmp.getText().toString().equals("4")){txtGirdi.setText(txtGirdi.getText()+bTmp.getText().toString());}
        if(bTmp.getText().toString().equals("5")){txtGirdi.setText(txtGirdi.getText()+bTmp.getText().toString());}
        if(bTmp.getText().toString().equals("6")){txtGirdi.setText(txtGirdi.getText()+bTmp.getText().toString());}
        if(bTmp.getText().toString().equals("7")){txtGirdi.setText(txtGirdi.getText()+bTmp.getText().toString());}
        if(bTmp.getText().toString().equals("8")){txtGirdi.setText(txtGirdi.getText()+bTmp.getText().toString());}
        if(bTmp.getText().toString().equals("9")){txtGirdi.setText(txtGirdi.getText()+bTmp.getText().toString());}

        if(bTmp.getText().toString().equals("MC")){    sM=0;
            new Timer().schedule(
                    new TimerTask(){
                        @Override
                        public void run(){
                            txtGirdi.setText("");
                        }
                    }, 2000);  txtGirdi.setText("MEMORY CLR");}


        if(bTmp.getText().toString().equals("M+")){txtGirdi.setText(""+sM);}
        if(bTmp.getText().toString().equals("M-")){txtGirdi.setText(""+sM*-1);}

        if(bTmp.getText().toString().equals("sil")){
            islemNo=-1;
            s1=0;
            s2=0;
            txtGirdi.setText("");
        }
        if(bTmp.getText().toString().equals("+")){
            islemNo=1;
            s1=Long.parseLong(txtGirdi.getText().toString());
            txtGirdi.setText("");
        }
        if(bTmp.getText().toString().equals("-")){
            islemNo=2;
            s1=Long.parseLong(txtGirdi.getText().toString());
            txtGirdi.setText("");
        }
        if(bTmp.getText().toString().equals("X")){
            islemNo=3;
            s1=Long.parseLong(txtGirdi.getText().toString());
            txtGirdi.setText("");
        }
        if(bTmp.getText().toString().equals("/")){
            islemNo=4;
            s1=Long.parseLong(txtGirdi.getText().toString());
            txtGirdi.setText("");
        }
        if(bTmp.getText().toString().equals("=")){
            try {
                s2=Long.parseLong(txtGirdi.getText().toString());
            }catch (Exception e){Toast.makeText(getApplicationContext(),"HATA \n=> "+e.toString(),Toast.LENGTH_LONG).show();}

          switch (islemNo){

              case 1:   txtGirdi.setText(""+(s1+s2));sM=s1+s2;  islemNo=-1;      break;
              case 2:   txtGirdi.setText(""+(s1-s2));sM=s1-s2;   islemNo=-1;     break;
              case 3:if(s2==0|s1==0){txtGirdi.setText(""+(0));sM=0; break;} islemNo=-1; try{ txtGirdi.setText(""+(s1*s2));sM=s1*s2; break;}catch (Exception e){txtGirdi.setText(""+(0)); sM=0;}       break;
              case 4:if(s2==0|s1==0){txtGirdi.setText(""+(0));sM=0; break;}  islemNo=-1; try{txtGirdi.setText(""+(s1/s2));sM=s1/s2; break;}catch (Exception e){txtGirdi.setText(""+(0)); sM=0;}         break;
              default:{try{new Timer().schedule(
                      new TimerTask(){
                          @Override
                          public void run(){
                              txtGirdi.setText("");
                          }
                      }, 2000);  txtGirdi.setText("Değer Girin!");}catch (Exception e){Toast.makeText(getApplicationContext(),"HATA \n=> "+e.toString(),Toast.LENGTH_LONG).show();}}

          }
          }

        }
    }


