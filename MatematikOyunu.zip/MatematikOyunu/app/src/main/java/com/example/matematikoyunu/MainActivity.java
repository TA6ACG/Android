package com.example.matematikoyunu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int seviye=0;
    String KullaniciAdi;
    RadioButton buton1;
    RadioButton  buton2;
    RadioButton  buton3;
    Button btnBasla;
    EditText girdiKadi;
    SharedPreferences hafiza;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); //ekranı dik başlatma kilidi
        buton1= (RadioButton)  findViewById(R.id.rbKolay);
        buton2= (RadioButton)  findViewById(R.id.rbOrta);
        buton3= (RadioButton)  findViewById(R.id.rbZor);
        buton2.setChecked(true);//on tanimli olarak orta seviye ayarli
        btnBasla= (Button)  findViewById(R.id.btnBasla);
        girdiKadi =(EditText) findViewById(R.id.edtKAdi);


        ////hafıza okuma /////
        hafiza = this.getSharedPreferences(getPackageName(),MODE_PRIVATE);
        String veri=
                hafiza.getString("1",null)+"\n"
                        +hafiza.getString("2",null)+"\n"
                        +hafiza.getString("3",null)+"\n"
                        +hafiza.getString("4",null)+"\n"
                        +hafiza.getString("5",null)+"\n";
        EditText scorBoard= (EditText) findViewById(R.id.edtScor);
        scorBoard.setText("Kullanıcı/Seviye/Puan"+"\n"+veri);
        /////////////////////
        //////////////////////////// radyo buton kontrolü///////////////////
        buton1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                seviye=1;
                buton2.setChecked(false);
                buton3.setChecked(false);

            }
        });
        buton2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                seviye=2;
                buton1.setChecked(false);
                buton3.setChecked(false);

            }
        });
        buton3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                seviye=3;
                buton1.setChecked(false);
                buton2.setChecked(false);

            }
        });
        ///////////////////////////////////// radyo buton kontrolü////////////

        btnBasla.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(seviye==0 || girdiKadi.equals("")){
                    Toast.makeText(getApplicationContext(), "Seviye ve Kullanıcı Adı Olmalı!", Toast.LENGTH_LONG).show();
                }
                else {
                    basla();



                }


            }
        });
    }
    public  void basla() {
        Intent intentBasla = new Intent(this, OyunAlani.class);

        String Kadi = girdiKadi.getText().toString();
        intentBasla.putExtra("Kadi", Kadi);
        intentBasla.putExtra("Seviye", seviye);
        startActivity(intentBasla);
    }

}