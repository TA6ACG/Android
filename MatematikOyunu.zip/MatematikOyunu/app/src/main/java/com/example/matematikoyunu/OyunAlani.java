package com.example.matematikoyunu;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class OyunAlani extends AppCompatActivity implements View.OnClickListener {
    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12;
    int x, y, puan = 30, sure = 120,cevap,Seviye;
    TextView txtPuan, txtSure, soruAlani;           //Degiskenlerimizi burda tamimlama nedenimiz classin her yerinden erisilir olmasini istememiz
    ArrayList<Button> butonlar = new ArrayList<Button>(); //butonlari icine koyacagimiz dizimiz
    CountDownTimer  geriSayici;
    String KullaniciAdi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyun_alani);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); //ekranı dik başlatma kilidi
        txtPuan = (TextView) findViewById(R.id.txtPuan);
        txtSure = (TextView) findViewById(R.id.txtSure);


        //yukarida kullanacagimiz arayuz elemanlarini tanimladik
        Intent GelenIntent = getIntent();
        KullaniciAdi = GelenIntent.getExtras().getString("Kadi","isim yok");
        Seviye = GelenIntent.getExtras().getInt("Seviye",1);
        b1 = (Button) findViewById(R.id.button1);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);
        b4 = (Button) findViewById(R.id.button4);
        b5 = (Button) findViewById(R.id.button5);
        b6 = (Button) findViewById(R.id.button6);
        b7 = (Button) findViewById(R.id.button7);
        b8 = (Button) findViewById(R.id.button8);
        b9 = (Button) findViewById(R.id.button9);
        b10 = (Button) findViewById(R.id.button10);
        b11 = (Button) findViewById(R.id.button11);
        b12 = (Button) findViewById(R.id.button12);
        //Butonlarımızı tanimladik
        butonlar.add(b1);
        butonlar.add(b2);
        butonlar.add(b3);
        butonlar.add(b4);
        butonlar.add(b5);
        butonlar.add(b6);
        butonlar.add(b7);
        butonlar.add(b8);
        butonlar.add(b9);
        butonlar.add(b10);
        butonlar.add(b11);
        butonlar.add(b12);
        //butonlarimizi arrayi listimize ekledik
        KutulariDoldur();
        geriSayim(120,txtSure); //sureyi baslatip 120 sn ye ye kurduk

    }




    @Override
    public void onClick(View view) {    //butona tiklandiginda arayuz bu metodu cagiracak
        Button bTmp=(Button) view;  //view i gecici bir butona atadik bu tiklanan butonumuz
        int tmpCevap=Integer.parseInt(bTmp.getText().toString());   //gelen cevabi int e cevirdik

        if(tmpCevap==cevap){    //Cevap doğru ise
            puan=puan+5;
            txtPuan.setText("SKOR:"+puan);

        }
        else {          //Cevap Yanlıs ise
            puan=puan-10;
            txtPuan.setText("SKOR:"+puan);
        }

        if(puan<=0){bitir();}
        KutulariDoldur();



    }
    public void KutulariDoldur() {
        soruAlani = (TextView) findViewById(R.id.txtSoruAlani);
        Random rnd = new Random();
          x = rnd.nextInt(10); //0 ile 10 arasında 2 rasgele sayi tanimladik
          y = rnd.nextInt(10);

        if(x==0||y==0) KutulariDoldur();    //sifira bolme hatasindan kurtulmak icin


        if(Seviye==1){  //Kolay Seviye
            int islem=rnd.nextInt(2);
            if(islem==1)    {cevap=x+y; soruAlani.setText(""+x+" + "+y+"  kaçtır?");}
            else  {cevap=x-y; soruAlani.setText(""+x+" - "+y+"  kaçtır?");}

        }


        if(Seviye==2){      //Orta Seviye
            int islem=rnd.nextInt(2);
            if(islem==1)    {cevap=x/y; soruAlani.setText(""+x+" / "+y+"  kaçtır?");}
            else  {cevap=x*y; soruAlani.setText(""+x+" X "+y+"  kaçtır?");}

        }


        if(Seviye==3){      //Zor Seviye
            int islem=rnd.nextInt(4);
            if(islem==1)    {cevap=x+y; soruAlani.setText(""+x+" + "+y+"  kaçtır?");}
            if(islem==2)    {cevap=x/y; soruAlani.setText(""+x+" / "+y+"  kaçtır?");}
            if(islem==3)    {cevap=x-y; soruAlani.setText(""+x+" - "+y+"  kaçtır?");}
            else            {cevap=x*y; soruAlani.setText(""+x+" X "+y+"  kaçtır?");}
        }


        int dogruCevapKutusu=rnd.nextInt(12);

           for (Button tumButonlar: butonlar) { tumButonlar.setText(""+rnd.nextInt(200));} //her kutuyu rasgele sayilarla doldurduk

        butonlar.get(dogruCevapKutusu).setText(""+cevap);  //tek bir tanesinede cevabı yerleştirdik

        if(puan<=0){bitir();}//puan sıfırlanınca oyunu bitir





    }
    public void geriSayim(int Seconds, final TextView tv){

        geriSayici = new CountDownTimer(Seconds* 1000+1000, 1000) {

            public void onTick(long millisUntilFinished) {
                int seconds = (int) (millisUntilFinished / 1000);
                int minutes = seconds / 60;
                seconds = seconds % 60;
                tv.setText("Kalan Süre : " + String.format("%02d", minutes)+ ":" + String.format("%02d", seconds));

                if(puan<=0){bitir();}//puan sıfırlanınca oyunu bitir




            }

            public void onFinish() {    //2 dakkika dolunca oyunu bitirecek
                tv.setText("Oyun Bitti");
                bitir();
            }

        }.start();
    }

    private void bitir() {
        geriSayici.cancel();    //sureyi durduruyoruz
        Toast.makeText(getApplicationContext(),"Oyun bitti",Toast.LENGTH_LONG);
        for (Button tumButonlar: butonlar) { tumButonlar.setVisibility(View.INVISIBLE);} //her kutuyu gorunmez yaptik
        SharedPreferences hafiza = this.getSharedPreferences(getPackageName(),MODE_PRIVATE);
        String Yazilacak=KullaniciAdi+"/"+Seviye+"/"+puan;
        hafiza.edit().putString("veriler",Yazilacak).apply();
        SharedPreferences hafizaOkuyucu=this.getSharedPreferences(getPackageName(),MODE_PRIVATE);;



            //hafizaya oyuncu verilerini ekliyoruz
        hafiza.edit().putString("5", hafizaOkuyucu.getString("4",null)).apply();
        hafiza.edit().putString("4", hafizaOkuyucu.getString("3",null)).apply();
        hafiza.edit().putString("3", hafizaOkuyucu.getString("2",null)).apply();
        hafiza.edit().putString("2", hafizaOkuyucu.getString("1",null)).apply();
        hafiza.edit().putString("1", Yazilacak).apply();



        AlertDialog.Builder soru = new AlertDialog.Builder(this);       //oyuna tekrar baslamak ister mi diye sormak icin
        soru.setTitle("Yeniden Başla");
        soru.setMessage("Tamam mı devam mı?");
        soru.setNegativeButton("Hayır Bitti", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"Oyun bitti",Toast.LENGTH_LONG);

                System.exit(0);
            }
        });
        soru.setPositiveButton("Oyuna Devam", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                recreate();
            }
        });
        soru.show();




    }


}
