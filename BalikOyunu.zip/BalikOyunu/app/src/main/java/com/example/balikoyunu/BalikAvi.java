package com.example.balikoyunu;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class BalikAvi extends AppCompatActivity {
    ImageButton imgBalik1,imgBalik2,imgBalik3,imgZehirli1,imgZehirli2,imgZehirli3,imgRandom;
    TextView txtSure,txtPuan;
    int puan=30,Seviye,SeviyeZaman, yakalananBalikSayisi =0;
    int sure;
     CountDownTimer  geriSayici;
    String KullaniciAdi;
    ArrayList<ImageButton> imgButtonlar=new ArrayList<ImageButton>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_balik_avi);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); //ekranı yan başlatma kilidi
        Intent GelenIntent = getIntent();
         KullaniciAdi = GelenIntent.getExtras().getString("Kadi","isim yok");
        Seviye = GelenIntent.getExtras().getInt("Seviye",1);
        Toast.makeText(getApplicationContext(), "Seviye="+Seviye+" Kadi="+KullaniciAdi, Toast.LENGTH_LONG).show();

        txtSure=findViewById(R.id.txtSure);
        txtPuan=findViewById(R.id.txtPuan);
       // imgRandom=findViewById(R.id.imgRandom);
        imgBalik1=findViewById(R.id.imgBalik1);
        imgBalik2=findViewById(R.id.imgBalik2);
        imgBalik3=findViewById(R.id.imgBalik3);
        imgZehirli1=findViewById(R.id.imgZehirli1);
        imgZehirli2=findViewById(R.id.imgZehirli2);
        imgZehirli3=findViewById(R.id.imgZehirli3);

        imgButtonlar.add(imgBalik1);
        imgButtonlar.add(imgBalik2);
        imgButtonlar.add(imgBalik3);
        imgButtonlar.add(imgZehirli1);
        imgButtonlar.add(imgZehirli2);
        imgButtonlar.add(imgZehirli3);

        switch(Seviye) {    //Seviyeleri zamana çevirme
            case 1: SeviyeZaman=1500;   break;
            case 2: SeviyeZaman=1200;   break;
            case 3: SeviyeZaman=900;    break;        }



        geriSayim(120,txtSure);

        imgBalik1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                yakalananBalikSayisi++;
                txtPuan.setText(""+(puan+5));
                puan=puan+5;
                imgBalik1.setVisibility(View.INVISIBLE);
            }
        });
        imgBalik2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                yakalananBalikSayisi++;
                txtPuan.setText(""+(puan+5));
                puan=puan+5;
                imgBalik2.setVisibility(View.INVISIBLE);
            }
        });
        imgBalik3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                yakalananBalikSayisi++;
                txtPuan.setText(""+(puan+5));
                puan=puan+5;
                imgBalik3.setVisibility(View.INVISIBLE);
            }
        });
        imgZehirli1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                yakalananBalikSayisi--;
                txtPuan.setText(""+(puan-10));
                puan=puan-10;
                imgZehirli1.setVisibility(View.INVISIBLE);
            }
        });
        imgZehirli2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                yakalananBalikSayisi--;
                txtPuan.setText(""+(puan-10));
                puan=puan-10;
                imgZehirli2.setVisibility(View.INVISIBLE);
            }
        });
        imgZehirli3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                yakalananBalikSayisi--;
                txtPuan.setText(""+(puan-10));
                puan=puan-10;
                imgZehirli3.setVisibility(View.INVISIBLE);
            }
        });

    }
    private void oyunuBitir() {
        geriSayici.cancel();
        hafizaGuncelle();
        for (ImageButton alayi: imgButtonlar) { alayi.setVisibility(View.INVISIBLE);}


        AlertDialog.Builder soru = new AlertDialog.Builder(this);
        soru.setTitle("Yeniden Başla");
        soru.setMessage("Tamam mı devam mı?");
        soru.setNegativeButton("Hayır Bitti", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"Oyun bitti",Toast.LENGTH_LONG);

                System.exit(0);
            }
        });
        soru.setPositiveButton("Oyuna Devam", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                recreate();
            }
        });
        soru.show();


    }


    private void konumDegistir(ImageButton tmpImg) {
        tmpImg.setVisibility(View.VISIBLE);
        float mevcutX = tmpImg.getX();
        float mevcutY = tmpImg.getY();
        float konumX = 0;
        float konumY = 0;

        Random rasgele = new Random();
        boolean yeterliDegisim = true;

        while(yeterliDegisim) {
            konumX = rasgele.nextInt(getResources().getDisplayMetrics().widthPixels-tmpImg.getWidth());
            konumY = rasgele.nextInt(getResources().getDisplayMetrics().heightPixels-tmpImg.getHeight());

            float fark1 = Math.abs(mevcutX - konumX);
            float fark2 = Math.abs(mevcutY - konumY);

            if(fark1>70&&fark2>150){
                yeterliDegisim = false;
            }

        }
        tmpImg.setX(konumX);
        tmpImg.setY(konumY);

    }
    public void geriSayim(int Seconds, final TextView tv){

         geriSayici = new CountDownTimer(Seconds* 1000+1000, 1000) {

            public void onTick(long millisUntilFinished) {
                int seconds = (int) (millisUntilFinished / 1000);
                int minutes = seconds / 60;
                seconds = seconds % 60;
                tv.setText("TIME : " + String.format("%02d", minutes)+ ":" + String.format("%02d", seconds));

                if(puan<=0){oyunuBitir();}//puan sıfırlanınca oyunu bitir
                Random rnd = new Random();
                int gosterilecekResimSayisi = rnd.nextInt(4);
                int zehirliMiDegilMi = rnd.nextInt(6);
                int nekadarSureSonra = rnd.nextInt(3);  //kaç saniyede türetileceği


                if(yakalananBalikSayisi%20==0){ SeviyeZaman= SeviyeZaman-(int)(SeviyeZaman*0.20);}//20 katlarında hızlanacak

                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        // ekranda kaç saniye görüneceği
                    }}, SeviyeZaman);


                for (ImageButton alayi: imgButtonlar) { alayi.setVisibility(View.INVISIBLE);}

                switch(gosterilecekResimSayisi) {
                    case 1:{konumDegistir(imgButtonlar.get(zehirliMiDegilMi)); }break;
                    case 2:{konumDegistir(imgButtonlar.get(zehirliMiDegilMi));zehirliMiDegilMi = rnd.nextInt(5);konumDegistir(imgButtonlar.get(zehirliMiDegilMi));  }break;
                    case 3:{konumDegistir(imgButtonlar.get(zehirliMiDegilMi));zehirliMiDegilMi = rnd.nextInt(5);konumDegistir(imgButtonlar.get(zehirliMiDegilMi));zehirliMiDegilMi = rnd.nextInt(5);konumDegistir(imgButtonlar.get(zehirliMiDegilMi));   }break;
                    case 4:{konumDegistir(imgButtonlar.get(zehirliMiDegilMi));zehirliMiDegilMi = rnd.nextInt(5);konumDegistir(imgButtonlar.get(zehirliMiDegilMi));zehirliMiDegilMi = rnd.nextInt(5);konumDegistir(imgButtonlar.get(zehirliMiDegilMi)); zehirliMiDegilMi = rnd.nextInt(5);konumDegistir(imgButtonlar.get(zehirliMiDegilMi));  }break;
                    case 0:{   }break;

                }

                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        // bu metod random saniye gecikme ile vermek için
                    }
                }, nekadarSureSonra*1000);


            }

            public void onFinish() {
                tv.setText("Oyun Bitti");
                oyunuBitir();
            }

        }.start();
    }
    public void hafizaGuncelle(){
        SharedPreferences hafiza = this.getSharedPreferences(getPackageName(),MODE_PRIVATE);
        String Yazilacak=KullaniciAdi+"/"+Seviye+"/"+puan;
        hafiza.edit().putString("veriler",Yazilacak).apply();
        SharedPreferences hafizaOkuyucu=this.getSharedPreferences(getPackageName(),MODE_PRIVATE);;




        hafiza.edit().putString("5", hafizaOkuyucu.getString("4",null)).apply();
        hafiza.edit().putString("4", hafizaOkuyucu.getString("3",null)).apply();
        hafiza.edit().putString("3", hafizaOkuyucu.getString("2",null)).apply();
        hafiza.edit().putString("2", hafizaOkuyucu.getString("1",null)).apply();
        hafiza.edit().putString("1", Yazilacak).apply();

    }

}
