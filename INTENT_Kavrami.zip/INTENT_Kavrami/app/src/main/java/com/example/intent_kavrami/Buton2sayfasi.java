package com.example.intent_kavrami;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Buton2sayfasi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buton2sayfasi);
        Button butonGoogle = (Button) findViewById(R.id.buttonGoogle);
        Button butonAra = (Button) findViewById(R.id.buttonAra);
        Button butonAyasofya= (Button) findViewById(R.id.buttonAyasofya);
        Button butonSMS= (Button) findViewById(R.id.buttonSms);


        butonAra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {  btnAra();   }  });

        butonGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {  btnGoogleAc();   }  });
        butonAyasofya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {  btnAyasofya();   }  });
        butonSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {  btnSMSyolla();   }  });

    }

    public void  btnSMSyolla() {
        Uri uri = Uri.parse("smsto:+905062610140");
        Intent intetnSMS = new Intent(Intent.ACTION_SENDTO, uri);
        intetnSMS.putExtra("sms_body", "Bu Mesaj Bir Intent Aracılığıyla Gönderldi");
        startActivity(intetnSMS);

    }
    public void btnGoogleAc() {
        Intent intentTarayiciAcma = new Intent(Intent.ACTION_VIEW);
        Uri uri = Uri.parse("http://www.google.com.tr");
        intentTarayiciAcma.setData(uri);
        startActivity(intentTarayiciAcma);

    }
    public void btnAyasofya() {
                Intent intentHaritadaKonumGosterme = new Intent(android.content.Intent.ACTION_VIEW,
                Uri.parse("geo:0,0?q=41.0085812,28.9802257 (Ayasofya)"));
                startActivity(intentHaritadaKonumGosterme);

    }
    public void btnAra() {
        Intent intentAramaBaslat = new Intent(Intent.ACTION_VIEW);
        Uri uri = Uri.parse("tel:+902123334499");
        intentAramaBaslat.setData(uri);
        startActivity(intentAramaBaslat);
    }
}
