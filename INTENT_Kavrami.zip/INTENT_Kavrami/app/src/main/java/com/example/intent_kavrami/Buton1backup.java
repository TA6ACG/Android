package com.example.intent_kavrami;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Buton1backup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buton1backup);



        Button butonGeri= (Button)  findViewById(R.id.buttonGeri);
        butonGeri.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                btnGeriAction();

            }
        });
    }
    public  void btnGeriAction() {
        Intent intent1 = new Intent(this, MainActivity.class);
        startActivity(intent1);
    }

}
