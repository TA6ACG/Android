package com.example.intent_kavrami;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.TextView;

public class Buton3sayfasi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buton3sayfasi);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        Intent GelenIntent = getIntent();
        String mesaj = GelenIntent.getExtras().getString("veri","Veri Gelmedi");
        TextView txt4=(TextView) findViewById(R.id.textView4);
        txt4.setText(mesaj);



        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/html");
                intent.putExtra(Intent.EXTRA_EMAIL, new String[] { "cagriseyfeli@gmail.com" });
                intent.putExtra(Intent.EXTRA_SUBJECT, "Android Intent Örneği");
                intent.putExtra(Intent.EXTRA_TEXT, "Bu mail intent kullanarak gönderilmiştir!");
                startActivity(Intent.createChooser(intent, "E-mail gönder"));

            }
        });
    }

}
