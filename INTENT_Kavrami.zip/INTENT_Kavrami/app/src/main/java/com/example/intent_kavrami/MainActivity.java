package com.example.intent_kavrami;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button  buton1= (Button)  findViewById(R.id.button1);
        Button  buton2= (Button)  findViewById(R.id.button2);
        Button  buton3= (Button)  findViewById(R.id.button3);


        buton1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                btn1Action();

            }
        });
        buton2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                btn2Action();

            }
        });
        buton3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                btn3Action();

            }
        });
    }

    public  void btn1Action() {
        Intent intent1 = new Intent(this, Buton1backup.class);
        startActivity(intent1);
    }
    public  void btn2Action() {
        Intent intent2 = new Intent(this, Buton2sayfasi.class);
        startActivity(intent2);
    }
    public  void btn3Action() {
        Intent intent3 = new Intent(this, Buton3sayfasi.class);
        EditText girdi=(EditText) findViewById(R.id.textView3);
        String mesaj = girdi.getText().toString();
        intent3.putExtra("veri", mesaj);

        startActivity(intent3);
    }
}
